<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_CURA Healthcare Service        We Care _b17f12</name>
   <tag></tag>
   <elementGuidId>c04a8e48-12de-4f55-8037-1313f23e7fa1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.text-vertical-center</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='top']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>31e07d72-7f61-41c4-a201-b0dc67286832</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-vertical-center</value>
      <webElementGuid>aa011074-771f-4cd1-9d63-e27a98af4c7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    </value>
      <webElementGuid>c5da1fde-6dfe-4394-bf4e-f1bab9fecb17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;top&quot;)/div[@class=&quot;text-vertical-center&quot;]</value>
      <webElementGuid>82fa690a-a821-44f5-b1f1-ac95fd978c84</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='top']/div</value>
      <webElementGuid>61282a54-f290-4cdd-9b9b-7b4eabffdf2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[1]/following::div[1]</value>
      <webElementGuid>c3884af6-79c3-44bb-929a-fd51dfedb55f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[1]/following::div[1]</value>
      <webElementGuid>843e15b9-73cb-443e-bdb0-e1ee062e8505</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>3c8b1c10-670d-4e11-b907-0d0d1490fc06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ' or . = '
        CURA Healthcare Service
        We Care About Your Health
        
        Make Appointment
    ')]</value>
      <webElementGuid>fdc47c3d-8f20-4454-9b09-c64ce59628f0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
