<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Search Bar</name>
   <tag></tag>
   <elementGuidId>125baee4-6660-4696-89c9-7d789f8aca28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div > div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/section/header/div/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>36fd3644-bae2-4121-a729-e7cd6e66250a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Search Bar</value>
      <webElementGuid>6cf7cf77-2b43-4140-a2fb-e4aecfb8e9c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout sc-281b23bc-0 kIvujX css-1307jsb&quot;]/header[@class=&quot;ant-layout-header sc-281b23bc-2 hdqxbp&quot;]/div[1]/div[1]</value>
      <webElementGuid>dd5d4fc5-c689-4457-8daf-155663576236</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/section/header/div/div</value>
      <webElementGuid>80df6a4a-f3b4-4d6b-86e0-8b3cc5d4ed4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/preceding::div[5]</value>
      <webElementGuid>3790f7eb-6813-44fe-9311-b005fc3e4e7b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Home'])[1]/preceding::div[7]</value>
      <webElementGuid>4c49246e-8e5d-40c8-bdad-53cffd1fc5b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Search Bar']/parent::*</value>
      <webElementGuid>68a3e0e6-be0a-4339-a9bf-cf9a04be39e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div</value>
      <webElementGuid>9705618e-c0cb-42c3-a994-78a7d34385ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Search Bar' or . = 'Search Bar')]</value>
      <webElementGuid>cfda933c-af9c-4bc6-9e18-55e4837ac9ac</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
