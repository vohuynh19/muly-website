<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Login Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>00db580a-93b1-4b8a-941e-89167a8eed6c</testSuiteGuid>
   <testCaseLink>
      <guid>8d33d3f4-4771-476d-82bb-527afdeddff2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Test Case</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>151cd407-ff58-433c-b235-5f968ce50539</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Login Test Data</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>151cd407-ff58-433c-b235-5f968ce50539</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>EMAIL</value>
         <variableId>23c8db91-4161-4b8f-880e-8325a039443a</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>151cd407-ff58-433c-b235-5f968ce50539</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>PASSWORD</value>
         <variableId>29ab5087-2413-4401-8326-64ad81ff8f84</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
