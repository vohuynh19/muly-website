<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Login Success</name>
   <tag></tag>
   <elementGuidId>d7456d89-1848-497c-85c6-8399435535d2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::div[5]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.ant-message-notice-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>8e6db38a-0144-4745-8174-478e67cb30b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-message-notice-content</value>
      <webElementGuid>e1f9772d-51e7-4609-9fb1-7a01e8b9a85f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Login Success</value>
      <webElementGuid>c76f2964-a474-4da5-9544-8e116e0430a4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;ant-message ant-message-top css-k83k30&quot;]/div[@class=&quot;ant-message-notice ant-message-notice-success css-k83k30&quot;]/div[@class=&quot;ant-message-notice-content&quot;]</value>
      <webElementGuid>770e2cd1-5739-4def-a56f-c8deb0ba5818</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::div[5]</value>
      <webElementGuid>dcdc189d-6e4a-49ee-a485-1482ddc68ccf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discussions'])[1]/following::div[6]</value>
      <webElementGuid>e952b8ab-5181-4740-8ab7-e16ce10708db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='English'])[1]/preceding::div[3]</value>
      <webElementGuid>8caa76ba-aa8c-4d62-a0d6-a099b959805f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div</value>
      <webElementGuid>4f291170-f8fc-46f5-bc0f-ce1415a0002d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Login Success' or . = 'Login Success')]</value>
      <webElementGuid>9971885b-4384-4cbf-8a12-0da97c95b69b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
