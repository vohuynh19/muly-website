<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Become A Streamer</name>
   <tag></tag>
   <elementGuidId>d5ce00ed-9025-4352-a740-518d37bfaeb8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/section/section/main/div/button/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-1307jsb.ant-btn-primary.ant-btn-lg > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>b3cd069a-1fa7-4381-86d5-6f79c8bbceb7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Become A Streamer</value>
      <webElementGuid>82812f02-32ea-4d95-adca-5340c57b61a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout sc-281b23bc-0 kIvujX css-1307jsb&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider sc-281b23bc-0 kIvujX css-1307jsb&quot;]/main[@class=&quot;ant-layout-content sc-281b23bc-4 LSREu&quot;]/div[@class=&quot;sc-e9d13960-6 ifDrYI&quot;]/button[@class=&quot;ant-btn css-1307jsb ant-btn-primary ant-btn-lg&quot;]/span[1]</value>
      <webElementGuid>4b6419c2-611f-47a5-aa3a-a19b174eda8e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/section/section/main/div/button/span</value>
      <webElementGuid>4d6fc7ef-3024-4761-98a6-38ff8969b877</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[1]/following::span[2]</value>
      <webElementGuid>13e720cf-3735-4e02-b780-9ceff6e44b9c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Stream'])[1]/following::span[3]</value>
      <webElementGuid>6687becd-61a2-438e-91d1-8073dfa26356</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/preceding::span[1]</value>
      <webElementGuid>091dae4a-921b-4722-a01d-0c33ce6acc68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About'])[1]/preceding::span[1]</value>
      <webElementGuid>b2109bea-c72a-42ad-a633-f27f904b017c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Become A Streamer']/parent::*</value>
      <webElementGuid>e2034598-30a7-4716-86e2-b9edf066452b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>fd092004-3308-429e-b21d-6449f697ce33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Become A Streamer' or . = 'Become A Streamer')]</value>
      <webElementGuid>5e054764-edeb-4ed2-bf43-ce4e863ee29a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/button/span</value>
      <webElementGuid>3586b4fc-f06e-4faa-ab6c-ff24e9b6f011</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
