<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Share screen</name>
   <tag></tag>
   <elementGuidId>c9718e02-291b-428e-a4bf-53b4cc39232a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/section/section/main/div/div[2]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ee64ee54-6d97-4735-8532-508947b58e04</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>sc-e9d13960-4 eDpYQD</value>
      <webElementGuid>d2c62218-ca44-4f51-93e0-830a84858c60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Share screen</value>
      <webElementGuid>4eaea0e2-233e-4077-945f-873611d9981b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout sc-281b23bc-0 kIvujX css-1307jsb&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider sc-281b23bc-0 kIvujX css-1307jsb&quot;]/main[@class=&quot;ant-layout-content sc-281b23bc-4 LSREu&quot;]/div[@class=&quot;sc-e9d13960-0 hItHeD&quot;]/div[@class=&quot;sc-e9d13960-3 WbnYP&quot;]/div[@class=&quot;sc-e9d13960-4 eDpYQD&quot;]</value>
      <webElementGuid>291d3c3a-8964-48c9-acf6-647bf37b625f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/section/section/main/div/div[2]/div[2]</value>
      <webElementGuid>717d6b06-457e-47d4-b9a2-4fd0508c180a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Turn on camera'])[1]/following::div[1]</value>
      <webElementGuid>2e357fbd-4a17-4918-a87f-ea5145d5c867</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Profile'])[1]/following::div[7]</value>
      <webElementGuid>719929b1-a9c0-4ede-8ce6-fdf782d44d0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Stream'])[1]/preceding::div[1]</value>
      <webElementGuid>f97d12ca-b675-401f-acc8-6db01ea5f7f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/preceding::div[1]</value>
      <webElementGuid>4cfcd6d8-a63a-4f6d-a6a3-5c5feabc7ad2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Share screen']/parent::*</value>
      <webElementGuid>d16b9a22-d48e-4100-9da3-82986ba0fb51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]/div[2]</value>
      <webElementGuid>02ff37d0-7f8b-4361-b01c-94ec6e93e812</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Share screen' or . = 'Share screen')]</value>
      <webElementGuid>8812500f-b512-4811-a824-4b1b0b41b6dc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
