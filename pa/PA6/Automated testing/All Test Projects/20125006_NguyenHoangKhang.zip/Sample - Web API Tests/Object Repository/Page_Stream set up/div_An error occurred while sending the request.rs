<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_An error occurred while sending the request</name>
   <tag></tag>
   <elementGuidId>cc56111c-0a8f-44df-8a88-9b90b8be1975</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ant-message-custom-content.ant-message-error</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='OK'])[1]/following::div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bb395299-164c-4383-bf4f-7797a838db9a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-message-custom-content ant-message-error</value>
      <webElementGuid>cb29975f-9729-46bf-bbb3-84bf6e3bd421</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>An error occurred while sending the request</value>
      <webElementGuid>e4f36027-7ed6-4456-8f8e-a9bb7813ae3f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;ant-message ant-message-top css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice ant-message-notice-error css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice-content&quot;]/div[@class=&quot;ant-message-custom-content ant-message-error&quot;]</value>
      <webElementGuid>0d94f254-cf37-403a-8b3c-71da73434ba2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OK'])[1]/following::div[5]</value>
      <webElementGuid>7d0306a5-1943-4940-b46b-e61cc8178ec1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cancel'])[1]/following::div[5]</value>
      <webElementGuid>5d188e46-1869-466f-8349-9a01d05337ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div</value>
      <webElementGuid>36d73c5a-a3cf-4be7-b937-1471d7967a08</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'An error occurred while sending the request' or . = 'An error occurred while sending the request')]</value>
      <webElementGuid>9c14a943-b080-4c0b-83ed-54bc540e529d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
