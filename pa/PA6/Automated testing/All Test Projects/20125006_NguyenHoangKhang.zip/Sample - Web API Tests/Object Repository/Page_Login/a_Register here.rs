<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Register here</name>
   <tag></tag>
   <elementGuidId>9fbaf6f6-37cc-4a8b-877f-b0f8e4361d5e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/section/section/main/div/div/form/div[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.register > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5ef4784f-f0a6-40fb-8fbd-99f971bb003a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/register</value>
      <webElementGuid>d368144c-1225-43c0-973d-ba3db4cd8220</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Register here</value>
      <webElementGuid>a8b8cdb7-a06b-439d-b568-7a545c1e7f12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout sc-281b23bc-0 kIvujX css-1307jsb&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider sc-281b23bc-0 kIvujX css-1307jsb&quot;]/main[@class=&quot;ant-layout-content sc-281b23bc-4 LSREu&quot;]/div[@class=&quot;sc-138e09e7-0 bAMEEp&quot;]/div[@class=&quot;sc-138e09e7-1 fUSqsL&quot;]/form[@class=&quot;ant-form ant-form-vertical css-1307jsb sc-138e09e7-2 eESYYr&quot;]/div[@class=&quot;register&quot;]/a[1]</value>
      <webElementGuid>0738ae19-c50e-4bf4-be50-40cc77bb7b8b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/section/section/main/div/div/form/div[3]/a</value>
      <webElementGuid>e612d8f1-c06e-4cee-87b3-b556ee12c18d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Register here')]</value>
      <webElementGuid>a804a523-085b-4d20-b8ff-2641616da8b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Password'])[1]/following::a[1]</value>
      <webElementGuid>b46332fb-872f-4ef9-8dbf-a2a9f6b979a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Login'])[2]/preceding::a[1]</value>
      <webElementGuid>eaba1e1a-70f7-4d56-8209-2de65a26b825</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Continue with'])[1]/preceding::a[1]</value>
      <webElementGuid>c7698fdd-85e9-4917-aeb5-81fd3f363ac0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Register here']/parent::*</value>
      <webElementGuid>a207edd6-a077-4ba5-80e4-a22b4a09916e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/register')]</value>
      <webElementGuid>b04a6700-fbe5-471c-ace4-ccbdee5c5191</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div[3]/a</value>
      <webElementGuid>806d2744-f9e1-46bc-955f-62c3eeed0707</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '/register' and (text() = 'Register here' or . = 'Register here')]</value>
      <webElementGuid>62089b2f-5c82-405e-b4e5-15c00ce9b472</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
