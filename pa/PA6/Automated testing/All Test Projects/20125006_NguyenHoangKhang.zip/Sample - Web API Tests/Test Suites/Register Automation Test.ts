<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Register Automation Test</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>eddc9663-183d-4287-af6b-27dbd0b2386e</testSuiteGuid>
   <testCaseLink>
      <guid>e463b029-84b6-40f6-9350-3054f43e7716</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Register Test</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>80ff074a-d65f-4d7a-97cf-eace24d7425c</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Register Data Test</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>80ff074a-d65f-4d7a-97cf-eace24d7425c</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>USERNAME</value>
         <variableId>2ea541f5-989a-4188-b391-6fbb04d85c35</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>80ff074a-d65f-4d7a-97cf-eace24d7425c</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>PASSWORD</value>
         <variableId>7d02131b-d7fd-4355-8660-4d3fef3d7007</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
