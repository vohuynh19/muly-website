<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Upload avatar success</name>
   <tag></tag>
   <elementGuidId>a28fbab5-bcc4-4059-9515-339cffba0a7d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.ant-message-custom-content.ant-message-success</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::div[7]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>8ec74a1c-fae4-4ac2-9ca8-cc4db98891bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ant-message-custom-content ant-message-success</value>
      <webElementGuid>21acd5b8-f986-44d1-ade3-2e5b0b408e6e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Upload avatar success</value>
      <webElementGuid>6a8e66c9-661b-480f-af3c-eeda6cb96392</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;ant-message ant-message-top css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice ant-message-notice-success css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice-content&quot;]/div[@class=&quot;ant-message-custom-content ant-message-success&quot;]</value>
      <webElementGuid>6fbc3c15-5368-451a-837a-0cbd453abe58</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::div[7]</value>
      <webElementGuid>68ecbaa0-36ee-4b2b-be1b-4c25e089f73f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discussions'])[1]/following::div[8]</value>
      <webElementGuid>f18a8ca8-6b1c-4814-9799-b5e62d5d77e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div</value>
      <webElementGuid>bfffad15-8cfa-41f1-a0cf-716a8bcf0402</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Upload avatar success' or . = 'Upload avatar success')]</value>
      <webElementGuid>ad4287e1-7512-4508-a33e-df202d66c086</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
