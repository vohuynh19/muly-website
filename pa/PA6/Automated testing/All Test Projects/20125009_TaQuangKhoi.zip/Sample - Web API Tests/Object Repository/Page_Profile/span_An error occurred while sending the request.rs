<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_An error occurred while sending the request</name>
   <tag></tag>
   <elementGuidId>3caa6367-1cef-4e0a-bdda-8542915a5ef2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>dd8f3453-8271-4c7f-a935-4e18e2e12253</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>An error occurred while sending the request</value>
      <webElementGuid>cb61b69d-adf3-492a-ad5e-76c8c6d8fa8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;ant-message ant-message-top css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice ant-message-notice-error css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice-content&quot;]/div[@class=&quot;ant-message-custom-content ant-message-error&quot;]/span[2]</value>
      <webElementGuid>ceb8e581-bae3-42db-9441-dc03eb19b6e4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::span[2]</value>
      <webElementGuid>0f156c58-abc7-4ff9-b897-e105fdff85ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discussions'])[1]/following::span[2]</value>
      <webElementGuid>b2e07d38-4e63-4a5f-a1aa-4826a1bee89c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='An error occurred while sending the request']/parent::*</value>
      <webElementGuid>a042620e-7295-490c-a7d7-48eba7122776</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[2]</value>
      <webElementGuid>3496f8cd-a05c-4466-9ef2-036d9dea83d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'An error occurred while sending the request' or . = 'An error occurred while sending the request')]</value>
      <webElementGuid>252fc417-f149-4d41-baa5-35c91e7440d3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
