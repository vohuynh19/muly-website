<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path</name>
   <tag></tag>
   <elementGuidId>836a89b3-9b2b-4903-a288-e9ef8f1bcb95</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeLarge.ant-popover-open.mui-style-tzssek-MuiSvgIcon-root > path</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
      <webElementGuid>a30b962e-4565-4421-9ff7-41ae3d7379a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm0 14c-2.03 0-4.43-.82-6.14-2.88C7.55 15.8 9.68 15 12 15s4.45.8 6.14 2.12C16.43 19.18 14.03 20 12 20z</value>
      <webElementGuid>96b4dbd7-79a2-44f0-ae15-6ecfd4671aca</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout styled__StyledLayout-sc-281b23bc-0 kFodph css-dev-only-do-not-override-1307jsb&quot;]/header[@class=&quot;ant-layout-header styled__StyledHeader-sc-281b23bc-2 fKiMWt&quot;]/div[@class=&quot;ant-space css-dev-only-do-not-override-1307jsb ant-space-horizontal ant-space-align-center&quot;]/div[@class=&quot;ant-space-item&quot;]/a[1]/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeLarge ant-popover-open mui-style-tzssek-MuiSvgIcon-root&quot;]/path[1]</value>
      <webElementGuid>5dde7e4d-3ded-4b3a-970e-75252c98dbe8</webElementGuid>
   </webElementProperties>
</WebElementEntity>
