<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Upload avatar success</name>
   <tag></tag>
   <elementGuidId>0de30e20-a96c-4628-bc03-6d0176733d2f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>618642e6-5050-431f-8411-d435333677d2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Upload avatar success</value>
      <webElementGuid>02aaa0ab-540c-4305-8f52-ac71311ebe4d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;ant-message ant-message-top css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice ant-message-notice-success css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice-content&quot;]/div[@class=&quot;ant-message-custom-content ant-message-success&quot;]/span[2]</value>
      <webElementGuid>01ddd1ae-4282-48d1-9634-f5ba60bb736a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::span[2]</value>
      <webElementGuid>9d4ad9f8-f9a8-47be-b084-b75943a09f41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discussions'])[1]/following::span[2]</value>
      <webElementGuid>ecfd1abe-6a6c-41c5-9c3e-e409dee99ee7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Upload avatar success']/parent::*</value>
      <webElementGuid>5e518d01-8c25-492b-bf72-4e6e2a52f4a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[2]</value>
      <webElementGuid>6e599a2b-cb22-4a9d-8a06-2ed36a9ec730</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Upload avatar success' or . = 'Upload avatar success')]</value>
      <webElementGuid>72eceaf8-3880-435e-9787-eba846cbc2ab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
