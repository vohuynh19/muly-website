<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Save Information</name>
   <tag></tag>
   <elementGuidId>96df3dcd-d960-474d-b0e7-632a2d3549e4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-dev-only-do-not-override-1307jsb.ant-btn-primary.ant-btn-lg > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/section/section/main/div/form/button/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>e4715b1d-fabb-4920-a62e-dde0d0e74e94</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Save Information</value>
      <webElementGuid>3d61d709-0e9f-479c-975a-57f941e68c53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout styled__StyledLayout-sc-281b23bc-0 kFodph css-dev-only-do-not-override-1307jsb&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider styled__StyledLayout-sc-281b23bc-0 kFodph css-dev-only-do-not-override-1307jsb&quot;]/main[@class=&quot;ant-layout-content styled__StyledContent-sc-281b23bc-4 fQrQfr&quot;]/div[@class=&quot;styled__Wrapper-sc-547e6e47-0 hZIGKN&quot;]/form[@class=&quot;ant-form ant-form-vertical css-dev-only-do-not-override-1307jsb styled__StyledForm-sc-547e6e47-1 wIfVz&quot;]/button[@class=&quot;ant-btn css-dev-only-do-not-override-1307jsb ant-btn-primary ant-btn-lg&quot;]/span[1]</value>
      <webElementGuid>d9f05b02-42d2-4601-b146-1ca7744e63ac</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/section/section/main/div/form/button/span</value>
      <webElementGuid>52909963-5fa2-49f9-bce9-b3f110b879ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email'])[1]/following::span[1]</value>
      <webElementGuid>510d7d47-008b-4d9b-bbcf-a9dc2ef08a83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Id'])[1]/following::span[1]</value>
      <webElementGuid>4af81869-9a81-46d7-b225-46433c98fd2e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About Us'])[1]/preceding::span[1]</value>
      <webElementGuid>698277c9-722d-4bd4-9386-07c68e2a0d4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='About'])[1]/preceding::span[1]</value>
      <webElementGuid>320fdda4-d3d1-4c75-820b-999128be2e1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Save Information']/parent::*</value>
      <webElementGuid>4adc78ec-876e-45b3-8a30-bbcec2d5cedb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>3cba22da-8330-48a9-9610-965c07c16e96</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Save Information' or . = 'Save Information')]</value>
      <webElementGuid>13ad225f-59f3-4ecc-ac1c-bd7f64b4370c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
