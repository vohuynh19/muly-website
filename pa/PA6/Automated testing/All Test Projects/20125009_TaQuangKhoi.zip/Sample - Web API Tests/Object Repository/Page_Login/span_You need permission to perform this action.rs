<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_You need permission to perform this action</name>
   <tag></tag>
   <elementGuidId>ebeee041-8817-492f-9dca-333b6000f82d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>0c6624ae-038e-463e-b016-d56406c5dd3e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>You need permission to perform this action</value>
      <webElementGuid>f29eaadd-5291-4f90-87ad-d5d4aec13779</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;ant-message ant-message-top css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice ant-message-notice-error css-dev-only-do-not-override-k83k30&quot;]/div[@class=&quot;ant-message-notice-content&quot;]/div[@class=&quot;ant-message-custom-content ant-message-error&quot;]/span[2]</value>
      <webElementGuid>cd4d5bb2-a77a-48d1-b926-258a2189d28a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Download now'])[1]/following::span[2]</value>
      <webElementGuid>9c54d5ac-a465-49bb-beb8-b98ccf63fabb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discussions'])[1]/following::span[2]</value>
      <webElementGuid>b251357b-cb07-4c18-8446-24d314a58fd9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='You need permission to perform this action']/parent::*</value>
      <webElementGuid>8d1ebfcd-d953-44eb-9614-9e4b261b8c30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/span[2]</value>
      <webElementGuid>f8eb5dd8-1ecd-4a52-a14f-d2c85be32f94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'You need permission to perform this action' or . = 'You need permission to perform this action')]</value>
      <webElementGuid>6190945e-b07c-4b3e-b066-bb762511e906</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
