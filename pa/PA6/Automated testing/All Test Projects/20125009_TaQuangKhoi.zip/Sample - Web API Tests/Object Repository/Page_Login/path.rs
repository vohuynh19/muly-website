<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path</name>
   <tag></tag>
   <elementGuidId>4a4fd74e-e3b4-47cc-9133-a019dd67fcef</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.anticon.anticon-eye-invisible.ant-input-password-icon > svg > path</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
      <webElementGuid>a31b66fe-f329-45e2-ae7f-b54fe2a871fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M942.2 486.2Q889.47 375.11 816.7 305l-50.88 50.88C807.31 395.53 843.45 447.4 874.7 512 791.5 684.2 673.4 766 512 766q-72.67 0-133.87-22.38L323 798.75Q408 838 512 838q288.3 0 430.2-300.3a60.29 60.29 0 000-51.5zm-63.57-320.64L836 122.88a8 8 0 00-11.32 0L715.31 232.2Q624.86 186 512 186q-288.3 0-430.2 300.3a60.3 60.3 0 000 51.5q56.69 119.4 136.5 191.41L112.48 835a8 8 0 000 11.31L155.17 889a8 8 0 0011.31 0l712.15-712.12a8 8 0 000-11.32zM149.3 512C232.6 339.8 350.7 258 512 258c54.54 0 104.13 9.36 149.12 28.39l-70.3 70.3a176 176 0 00-238.13 238.13l-83.42 83.42C223.1 637.49 183.3 582.28 149.3 512zm246.7 0a112.11 112.11 0 01146.2-106.69L401.31 546.2A112 112 0 01396 512z</value>
      <webElementGuid>4d9182cd-a82b-46bb-9ec2-ee3c55bd3d7e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout styled__StyledLayout-sc-281b23bc-0 kFodph css-dev-only-do-not-override-1307jsb&quot;]/section[@class=&quot;ant-layout ant-layout-has-sider styled__StyledLayout-sc-281b23bc-0 kFodph css-dev-only-do-not-override-1307jsb&quot;]/main[@class=&quot;ant-layout-content styled__StyledContent-sc-281b23bc-4 fQrQfr&quot;]/div[@class=&quot;styled__Wrapper-sc-138e09e7-0 ZNFgY&quot;]/div[@class=&quot;styled__Container-sc-138e09e7-1 byaNau&quot;]/form[@class=&quot;ant-form ant-form-vertical css-dev-only-do-not-override-1307jsb styled__StyledForm-sc-138e09e7-2 kavJsS&quot;]/div[@class=&quot;ant-form-item css-dev-only-do-not-override-1307jsb ant-form-item-has-success&quot;]/div[@class=&quot;ant-row ant-form-item-row css-dev-only-do-not-override-1307jsb&quot;]/div[@class=&quot;ant-col ant-form-item-control css-dev-only-do-not-override-1307jsb&quot;]/div[@class=&quot;ant-form-item-control-input&quot;]/div[@class=&quot;ant-form-item-control-input-content&quot;]/span[@class=&quot;ant-input-affix-wrapper ant-input-affix-wrapper-focused ant-input-password ant-input-password-large ant-input-affix-wrapper-lg ant-input-affix-wrapper-status-success css-dev-only-do-not-override-1307jsb&quot;]/span[@class=&quot;ant-input-suffix&quot;]/span[@class=&quot;anticon anticon-eye-invisible ant-input-password-icon&quot;]/svg[1]/path[1]</value>
      <webElementGuid>a3f97bbf-de73-4e0a-b40f-c991d674f39e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
