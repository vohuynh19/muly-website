<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path</name>
   <tag></tag>
   <elementGuidId>86e652ec-2b16-44ec-8437-95dd38c2208c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeLarge.ant-popover-open.mui-style-tzssek-MuiSvgIcon-root > path</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
      <webElementGuid>29bf35f5-7603-48c9-b49f-c7166b1a74cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 4c1.93 0 3.5 1.57 3.5 3.5S13.93 13 12 13s-3.5-1.57-3.5-3.5S10.07 6 12 6zm0 14c-2.03 0-4.43-.82-6.14-2.88C7.55 15.8 9.68 15 12 15s4.45.8 6.14 2.12C16.43 19.18 14.03 20 12 20z</value>
      <webElementGuid>a7faa23e-f137-440e-8245-1880445698e4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/section[@class=&quot;ant-layout styled__StyledLayout-sc-281b23bc-0 kFodph css-dev-only-do-not-override-1307jsb&quot;]/header[@class=&quot;ant-layout-header styled__StyledHeader-sc-281b23bc-2 fKiMWt&quot;]/div[@class=&quot;ant-space css-dev-only-do-not-override-1307jsb ant-space-horizontal ant-space-align-center&quot;]/div[@class=&quot;ant-space-item&quot;]/a[1]/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeLarge ant-popover-open mui-style-tzssek-MuiSvgIcon-root&quot;]/path[1]</value>
      <webElementGuid>23effb16-5deb-4f68-ad82-e60d4ae553b0</webElementGuid>
   </webElementProperties>
</WebElementEntity>
