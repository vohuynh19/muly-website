<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Automation Upload Testing</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>ffc56699-0d17-424f-8ffb-2333a74a6aab</testSuiteGuid>
   <testCaseLink>
      <guid>d54b587f-b6d6-46cc-98af-adc0a8a57005</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Managing User Profie</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>806475d3-71eb-4612-8021-a69905215d0a</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Upload Image Profile</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>806475d3-71eb-4612-8021-a69905215d0a</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>image</value>
         <variableId>c00fe938-0b2d-47c9-a72b-d241d7b7d5a1</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
